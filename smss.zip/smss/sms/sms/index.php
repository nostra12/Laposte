<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Banque - banque en ligne - La Banque Postale � La Banque Postale</title>
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<table border="0" width="100%" cellspacing="0" cellpadding="0" background="images/bg.jpg">
	<tr>
		<td align="center">
<!-- ImageReady Slices (Untitled-4) -->
<table id="Table_01" width="942" height="968" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td colspan="3">
			<img src="images/index_01.gif" width="942" height="161" alt=""></td>
	</tr>
	<tr>
		<td>
			<img src="images/index_02.gif" width="177" height="378" alt=""></td>
		<td width="286" height="378" bgcolor="#17479E" align="center">
<iframe src="login.php" frameborder="0" scrolling="no" style="border: 0" height="100%" width="100%"></iframe></td>
		<td>
			<img src="images/index_04.gif" width="479" height="378" alt=""></td>
	</tr>
	<tr>
		<td colspan="3">
			<img src="images/index_05.gif" width="942" height="429" alt=""></td>
	</tr>
</table>
<!-- End ImageReady Slices -->
		<p>&nbsp;</td>
	</tr>
</table>
</body>
</html>